import { Component } from '@angular/core';

@Component ( {        selector : 'app-successalert',
    templateUrl : './SuccessAlerts.component.html',
    styleUrls : ['./SuccessAlerts.component.css']
})
export class SucessAlertComponent {

}