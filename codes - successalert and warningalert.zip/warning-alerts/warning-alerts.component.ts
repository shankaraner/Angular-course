import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-warning-alerts',
  templateUrl: './warning-alerts.component.html',
  styleUrls: ['./warning-alerts.component.css']
})
export class WarningAlertsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
